# simple-crud-ajax

-----------------------
Nama : Fatah Widiyanto<br>
NIM  : 135410241
-----------------------

CARA MENGGUNAKAN
- database otomatis terbuat ketika membuka file index.php 
